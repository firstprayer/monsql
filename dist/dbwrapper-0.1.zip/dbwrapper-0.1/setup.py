from distutils.core import setup

setup(name='dbwrapper',
      version='0.1',
      package_dir={'dbwrapper': 'dbwrapper'},
      )