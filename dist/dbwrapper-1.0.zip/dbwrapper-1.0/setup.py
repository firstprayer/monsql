from distutils.core import setup
setup(name='dbwrapper',
      version='1.0',
      py_modules=['dbwrapper'],
      )