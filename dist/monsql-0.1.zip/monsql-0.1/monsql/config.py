# coding=utf-8

ASCENDING = 1
DESCENDING = 2